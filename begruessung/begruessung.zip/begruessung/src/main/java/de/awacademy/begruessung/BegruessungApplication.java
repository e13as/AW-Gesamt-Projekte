package de.awacademy.begruessung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BegruessungApplication {

	public static void main(String[] args) {
		SpringApplication.run(BegruessungApplication.class, args);
	}

}
